import React from "react";
import Gambar from "../assets/gambar1.png";

export default function () {
  return (
    <div class="flex flex-col md:flex-row items-center md:justify-between py-4 md:py-8">
      <div class="md:w-1/2 lg:w-2/3 px-4 md:px-0 text-left	">
        <h1 class="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-4">
          Temukan Beragam
        </h1>
        <h1 class="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-4">
          Pilihan Kuliner
        </h1>
        <h1 class="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-4">
          di Foodcourt
        </h1>
        <h1 class="text-4xl mb-8 md:text-5xl lg:text-6xl font-bold leading-tight mb-4 text-teal-500">
          Bu Nenden
        </h1>
        <button class="bg-white w-48 text-teal-500 font-bold py-2 px-4 rounded-lg border-2 border-teal-500 hover:bg-teal-500 hover:text-white hover:border-teal-500">
          Pesan Segera!
        </button>
      </div>
      <div class="relative">
        <img
          class="bottom-0 right-0 w-full h-full"
          src={Gambar}
          alt="Gambar Unsplash"
        />
      </div>
    </div>
  );
}
